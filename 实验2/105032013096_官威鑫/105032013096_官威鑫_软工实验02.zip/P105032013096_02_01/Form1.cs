﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P105032013096_02_01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((int)e.KeyChar < 48 || (int)e.KeyChar > 57) && (int)e.KeyChar != 8 && (int)e.KeyChar != 46)
              e.Handled = true;

            if ((int)e.KeyChar == 46)
            {
                if (textBox1.TextLength <= 0)
                    e.Handled = true;
                if (textBox1.Text.Contains("."))
                    e.Handled = true;
            }

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((int)e.KeyChar < 48 || (int)e.KeyChar > 57) && (int)e.KeyChar != 8 && (int)e.KeyChar != 46)
                e.Handled = true;

            if ((int)e.KeyChar == 46)
            {
                if (textBox2.TextLength <= 0)
                    e.Handled = true;
                if (textBox2.Text.Contains("."))
                    e.Handled = true;
            }

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((int)e.KeyChar < 48 || (int)e.KeyChar > 57) && (int)e.KeyChar != 8 && (int)e.KeyChar != 46)
                e.Handled = true;

            if ((int)e.KeyChar == 46)
            {
                if (textBox3.TextLength <= 0)
                    e.Handled = true;
                if (textBox3.Text.Contains("."))
                    e.Handled = true;
            }
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((int)e.KeyChar < 48 || (int)e.KeyChar > 57) && (int)e.KeyChar != 8 && (int)e.KeyChar != 46)
                e.Handled = true;

            if ((int)e.KeyChar == 46)
            {
                if (textBox7.TextLength <= 0)
                    e.Handled = true;
                if (textBox7.Text.Contains("."))
                    e.Handled = true;
            }
        }

        private void textBox10_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((int)e.KeyChar < 48 || (int)e.KeyChar > 57) && (int)e.KeyChar != 8 && (int)e.KeyChar != 46)
                e.Handled = true;//控制输入的只能为数字

            if ((int)e.KeyChar == 46)
            {
                if (textBox10.TextLength <= 0)
                    e.Handled = true;//小数点如果在第一位则不能输入
                if (textBox10.Text.Contains("."))
                    e.Handled = true;//判断小数点个数超过一个则不能继续输入
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float MonthReturn;
            float TotalExtra;
            float Totalreturn;
            float d = float.Parse(textBox1.Text);//parse方法把string类型转化成float型
            float y = float.Parse(textBox2.Text) / 12;
            float n = float.Parse(textBox3.Text);
            MonthReturn = d * y / (1 - (1 + y) - n);
            Totalreturn = MonthReturn * n * 12;
            TotalExtra = Totalreturn - d;
            textBox4.Text = string.Format("{0:C}", Totalreturn);//convert方法将float型转化为string型Convert.ToString(Totalreturn)
            textBox5.Text = string.Format("{0:C}",TotalExtra);
            textBox6.Text = string.Format("{0:C}",MonthReturn);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            float GetMoney;
            float c = float.Parse(textBox7.Text);
            float b = float.Parse(textBox10.Text);
            TimeSpan ts = dateTimePicker2.Value - dateTimePicker1.Value;//计算datetimepicker可以用timespan类
            float m = (float)ts.TotalDays / 30;
            GetMoney=c*((1+b)*m-1);
            textBox11.Text =string.Format("{0:C}", GetMoney);
        }


    }
}
